/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <math.h>
#include <include_juce_audio_processors.cpp>
using namespace juce::AudioProcessor;

//==============================================================================
NoiseGateAudioProcessor::NoiseGateAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
    : AudioProcessor(BusesProperties()
#if ! JucePlugin_IsMidiEffect
#if ! JucePlugin_IsSynth
        .withInput("Input", juce::AudioChannelSet::stereo(), true)
#endif
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)
#endif
    )
#endif
{
    UserParams[uthcnt] = 0.0f; //initial, valoarea de dezactivare e 0
    UIUpdateFlag = true;
    UserParams[lthcnt] = 0.0f; // initial, valoarea de activare e 0
    UIUpdateFlag = true;
    UserParams[holdtime] = 0.0f; // initial, timpul pt lthcnt e 0
    UIUpdateFlag = true;
    UserParams[attack] = 20.0f; // valoare initiala 20s
    UIUpdateFlag = true;
    UserParams[release] = 1000.0f; // valoare initiala 1000s
    UIUpdateFlag = true;
    UserParams[alpha] = 0.0f; // valoare initiala 1000s
    UIUpdateFlag = true;
}


NoiseGateAudioProcessor::~NoiseGateAudioProcessor()
{
}

//==============================================================================
const juce::String NoiseGateAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool NoiseGateAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool NoiseGateAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool NoiseGateAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double NoiseGateAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int NoiseGateAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int NoiseGateAudioProcessor::getCurrentProgram()
{
    return 0;
}

void NoiseGateAudioProcessor::setCurrentProgram (int index)
{
}

const juce::String NoiseGateAudioProcessor::getProgramName (int index)
{
    return {};
}

void NoiseGateAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void NoiseGateAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    // Use this method as the place to do any pre-playback
    // initialisation that you need..
}

void NoiseGateAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool NoiseGateAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void NoiseGateAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    // In case we have more outputs than inputs, this code clears any output
    // channels that didn't contain input data, (because these aren't
    // guaranteed to be empty - they may contain garbage).
    // This is here to avoid people getting screaming feedback
    // when they first compile a plugin, but obviously you don't need to keep
    // this code if your algorithm always overwrites all the output channels.
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());

    // This is the place where you'd normally do the guts of your plugin's
    // audio processing...
    // Make sure to reset the state if your inner loop is processing
    // the samples and the outer loop is handling the channels.
    // Alternatively, you can process the samples with the channels
    // interleaved by keeping the same state.
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        auto* channelData = buffer.getWritePointer (channel);

        double rel = round(release * getSampleRate());
        double att = round(attack * getSampleRate());
        double ht = round(holdtime * getSampleRate());
        double ymax = 0.001;
        double xmax = 0.001;
        double hmax = 0.001;
        double ltrhold = 0;
        double utrhold = 0;
        std::vector<double>g(buffer.getNumSamples(), 0);
        std::vector<double>y(buffer.getNumSamples());


        // ..do something to the data...

        for (int j = 0; j < buffer.getNumSamples(); j++)
        {
            channelData[j] = channelData[j] * powf(10.f, UserParams[uthcnt] / 20.f);
            channelData[j] = channelData[j] * powf(10.f, UserParams[lthcnt] / 20.f);
            channelData[j] = channelData[j] * powf(10.f, UserParams[holdtime] / 20.f);
            channelData[j] = channelData[j] * powf(10.f, UserParams[attack] / 20.f);
            channelData[j] = channelData[j] * powf(10.f, UserParams[release] / 20.f);
            channelData[j] = channelData[j] * powf(10.f, UserParams[alpha] / 20.f);

        }
        

        for (int j = 0; j < buffer.getNumSamples(); j++)
        {
            for (int i = 0; i < buffer.getNumSamples(); i++)
            {
                std::vector<double>h[(1 - alpha) * (1 - alpha)] [(1, - 2 * alpha, alpha * alpha)] [abs(channelData[j])];
                h[i][j] = h[i][j] / hmax;

                if (((h[i][j] / hmax) <= lthcnt) || (((h[i][j] / hmax) < uthcnt) && (ltrhold > 0)))
                {
                    ltrhold++;
                    utrhold = 0;

                    if (ltrhold > ht)
                    {
                        if (ltrhold > (rel + ht))
                        {
                            g[i] = 0;
                        }
                        else
                        {
                            g[i] = 1 - (ltrhold - ht) / rel;
                        }
                    }
                    else if ((i < ht) && (ltrhold == 1))
                    {
                        g[i] = 0;
                    }

                    else
                    {
                        g[i] = 1;
                    }

                    }

                else if(((h[i][j]/hmax) >= uthcnt) || (((h[i][j]/hmax) > lthcnt) && (utrhold > 0)))
                {
                utrhold++;

                if (g[i - 1] < 1)
                {
                    if (utrhold/att > g[i-1])
                    {g[i] = utrhold/att;
                    }
                    else
                    {
                        g[i] = g[i - 1];
                    }
                }
                else
                {
                    g[i] = 0;
                    ltrhold = 0;
                }

                }

                else
                    {
                        g[i] = g[i - 1];
                        ltrhold = 0;
                        utrhold = 0;
                    }

                }
                y[i][j] = channelData[j] * g[i];
            }
        }

    }
}

//==============================================================================
bool NoiseGateAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* NoiseGateAudioProcessor::createEditor()
{
    return new NoiseGateAudioProcessorEditor (this);
}

//==============================================================================
void NoiseGateAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
    XmlElement root("Root");
    XmlElement* el1, * el2, * el3, * el4, * el5, * el6;

    el1 = root.createNewChildElement("Uthcnt");
    el1->addTextElement(String(UserParams[uthcnt]));

    el2 = root.createNewChildElement("Lthcnt");
    el2->addTextElement(String(UserParams[lthcnt]));

    el3 = root.createNewChildElement("Holdtime");
    el3->addTextElement(String(UserParams[holdtime]));

    el4 = root.createNewChildElement("Attack");
    el4->addTextElement(String(UserParams[attack]));

    el5 = root.createNewChildElement("Release");
    el5->addTextElement(String(UserParams[release]));

    el6 = root.createNewChildElement("Alpha");
    el6->addTextElement(String(UserParams[alpha]));

    copyXmlToBinary(root, destData);
}

void NoiseGateAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.

    static std::unique_ptr< XmlElement > pRoot = getXmlFromBinary(data, sizeInBytes);
    if (pRoot != NULL)
    {
        forEachXmlChildElement((*pRoot), pChild)
        {
            if (pChild->hasTagName("Uthcnt"))
            {
                String text = pChild->getAllSubText();
                setParameter(uthcnt, text.getFloatValue());
            }

            if (pChild->hasTagName("Lthcnt"))
            {
                String text = pChild->getAllSubText();
                setParameter(lthcnt, text.getFloatValue());
            }

            if (pChild->hasTagName("Holdtime"))
            {
                String text = pChild->getAllSubText();
                setParameter(holdtime, text.getFloatValue());
            }

            if (pChild->hasTagName("Release"))
            {
                String text = pChild->getAllSubText();
                setParameter(release, text.getFloatValue());
            }

            if (pChild->hasTagName("Attack"))
            {
                String text = pChild->getAllSubText();
                setParameter(attack, text.getFloatValue());
            }

            if (pChild->hasTagName("Alpha"))
            {
                String text = pChild->getAllSubText();
                setParameter(alpha, text.getFloatValue());
            }
        }

        UIUpdateFlag = true;
    }




}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new NoiseGateAudioProcessor();
}

int NoiseGateAudioProcessor::getNumParameters()
{
    return totalNumParam;
}

float NoiseGateAudioProcessor::getParameter(int index)
{
    switch (index)
    {
    case uthcnt:
        return UserParams[uthcnt];
    case lthcnt:
        return UserParams[lthcnt];
    case holdtime:
        return UserParams[holdtime];
    case release:
        return UserParams[release];
    case attack:
        return UserParams[attack];
    case alpha:
        return UserParams[alpha];

    default: return 0.0f; // index invalid
    }
}


void NoiseGateAudioProcessor::setParameter(int index, float newValue)
{
    switch (index)
    {
    case uthcnt:
        UserParams[uthcnt] = newValue;
        break;
    case lthcnt:
        UserParams[lthcnt] = newValue;
        break;
    case holdtime:
        UserParams[holdtime] = newValue;
        break;
    case release:
        UserParams[release] = newValue;
        break;
    case attack:
        UserParams[attack] = newValue;
        break;
    case alpha:
        UserParams[alpha] = newValue;
        break;
    default: return;
    }
    UIUpdateFlag = true;//Request UI update -- Some OSX hosts use alternate editors, this updates ours
}

const String NoiseGateAudioProcessor::getParameterName(int index)
{
    switch (index)
    {
    case uthcnt: return "Uthcnt";
        break;
    case lthcnt: return "Lthcnt";
        break;
    case holdtime: return "Holdtime";
        break;
    case release: return "Release";
        break;
    case attack: return "Attack";
        break;
    case alpha: return "Alpha";
    default:return String();
    }
}

const String NoiseGateAudioProcessor::getParameterText(int index)
{
    if (index >= 0 && index < totalNumParam)
        return String(UserParams[index]);
    else return String();
}
