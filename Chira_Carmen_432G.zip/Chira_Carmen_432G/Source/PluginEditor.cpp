/*
  ==============================================================================

  This is an automatically generated GUI class created by the Projucer!

  Be careful when adding custom code to these files, as only the code within
  the "//[xyz]" and "//[/xyz]" sections will be retained when the file is loaded
  and re-saved.

  Created with Projucer version: 6.0.7

  ------------------------------------------------------------------------------

  The Projucer is part of the JUCE library.
  Copyright (c) 2020 - Raw Material Software Limited.

  ==============================================================================
*/

//[Headers] You can add your own extra header files here...
//[/Headers]

#include "PluginEditor.h"


//[MiscUserDefs] You can add your own user definitions and misc code here...
//[/MiscUserDefs]

//==============================================================================
NoiseGateAudioProcessorEditor::NoiseGateAudioProcessorEditor (NoiseGateAudioProcessor* ownerFilter)
    : AudioProcessorEditor(ownerFilter)
{
    //[Constructor_pre] You can add your own custom stuff here..
    //[/Constructor_pre]

    uthcntSlider.reset (new juce::Slider ("Uthcnt Slider"));
    addAndMakeVisible (uthcntSlider.get());
    uthcntSlider->setRange (0, -140, 1);
    uthcntSlider->setSliderStyle (juce::Slider::LinearHorizontal);
    uthcntSlider->setTextBoxStyle (juce::Slider::TextBoxLeft, false, 80, 20);
    uthcntSlider->setColour (juce::Slider::thumbColourId, juce::Colour (0xff9a39e1));
    uthcntSlider->setColour (juce::Slider::textBoxOutlineColourId, juce::Colour (0xffb775f0));
    uthcntSlider->addListener (this);

    uthcntSlider->setBounds (16, 56, 167, 24);

    uthcntLabel.reset (new juce::Label ("Uthcnt Label",
                                        TRANS("Uthcnt Label(deactivates the Noise Gate)")));
    addAndMakeVisible (uthcntLabel.get());
    uthcntLabel->setFont (juce::Font (15.10f, juce::Font::plain).withTypefaceStyle ("Regular"));
    uthcntLabel->setJustificationType (juce::Justification::centredLeft);
    uthcntLabel->setEditable (false, false, false);
    uthcntLabel->setColour (juce::TextEditor::textColourId, juce::Colours::black);
    uthcntLabel->setColour (juce::TextEditor::backgroundColourId, juce::Colour (0x00000000));

    uthcntLabel->setBounds (16, -8, 175, 80);

    lthcntSlider.reset (new juce::Slider ("Lthcnt Slider"));
    addAndMakeVisible (lthcntSlider.get());
    lthcntSlider->setRange (-60, 0, 1);
    lthcntSlider->setSliderStyle (juce::Slider::LinearHorizontal);
    lthcntSlider->setTextBoxStyle (juce::Slider::TextBoxLeft, false, 80, 20);
    lthcntSlider->setColour (juce::Slider::thumbColourId, juce::Colours::blueviolet);
    lthcntSlider->setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::blueviolet);
    lthcntSlider->addListener (this);

    lthcntSlider->setBounds (368, 56, 160, 24);

    lthcntLabel.reset (new juce::Label ("Lthcnt Label",
                                        TRANS("Lthcnt Label (activates the Noise Gate)")));
    addAndMakeVisible (lthcntLabel.get());
    lthcntLabel->setFont (juce::Font (15.60f, juce::Font::plain).withTypefaceStyle ("Regular"));
    lthcntLabel->setJustificationType (juce::Justification::centredLeft);
    lthcntLabel->setEditable (false, false, false);
    lthcntLabel->setColour (juce::TextEditor::textColourId, juce::Colours::black);
    lthcntLabel->setColour (juce::TextEditor::backgroundColourId, juce::Colour (0x00000000));

    lthcntLabel->setBounds (368, -8, 184, 72);

    holdtimeSlider.reset (new juce::Slider ("Holdtime Slider"));
    addAndMakeVisible (holdtimeSlider.get());
    holdtimeSlider->setRange (0, 4, 0);
    holdtimeSlider->setSliderStyle (juce::Slider::LinearHorizontal);
    holdtimeSlider->setTextBoxStyle (juce::Slider::TextBoxLeft, false, 80, 20);
    holdtimeSlider->setColour (juce::Slider::thumbColourId, juce::Colours::blueviolet);
    holdtimeSlider->setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::blueviolet);
    holdtimeSlider->addListener (this);

    holdtimeSlider->setBounds (16, 152, 160, 24);

    holdtimeLabel.reset (new juce::Label ("Holdtime Label",
                                          TRANS("Holdtime Label (time (s) the sound has the value of Lthcnt before the Noise Gate activates)")));
    addAndMakeVisible (holdtimeLabel.get());
    holdtimeLabel->setFont (juce::Font (15.00f, juce::Font::plain).withTypefaceStyle ("Regular"));
    holdtimeLabel->setJustificationType (juce::Justification::centredLeft);
    holdtimeLabel->setEditable (false, false, false);
    holdtimeLabel->setColour (juce::TextEditor::textColourId, juce::Colours::black);
    holdtimeLabel->setColour (juce::TextEditor::backgroundColourId, juce::Colour (0x00000000));

    holdtimeLabel->setBounds (8, 80, 256, 72);

    releaseSlider.reset (new juce::Slider ("Release Slider"));
    addAndMakeVisible (releaseSlider.get());
    releaseSlider->setRange (0, 4, 0);
    releaseSlider->setSliderStyle (juce::Slider::LinearHorizontal);
    releaseSlider->setTextBoxStyle (juce::Slider::TextBoxLeft, false, 80, 20);
    releaseSlider->setColour (juce::Slider::thumbColourId, juce::Colours::blueviolet);
    releaseSlider->setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::blueviolet);
    releaseSlider->addListener (this);

    releaseSlider->setBounds (24, 256, 152, 24);

    releaseLabel.reset (new juce::Label ("Release Label",
                                         TRANS("Release Label (time(s) before the sound level reaches 0)")));
    addAndMakeVisible (releaseLabel.get());
    releaseLabel->setFont (juce::Font (15.00f, juce::Font::plain).withTypefaceStyle ("Regular"));
    releaseLabel->setJustificationType (juce::Justification::centredLeft);
    releaseLabel->setEditable (false, false, false);
    releaseLabel->setColour (juce::TextEditor::textColourId, juce::Colours::black);
    releaseLabel->setColour (juce::TextEditor::backgroundColourId, juce::Colour (0x00000000));

    releaseLabel->setBounds (16, 200, 231, 40);

    attackSlider.reset (new juce::Slider ("Attack Slider"));
    addAndMakeVisible (attackSlider.get());
    attackSlider->setRange (0, 4, 0);
    attackSlider->setSliderStyle (juce::Slider::LinearHorizontal);
    attackSlider->setTextBoxStyle (juce::Slider::TextBoxLeft, false, 80, 20);
    attackSlider->setColour (juce::Slider::thumbColourId, juce::Colours::blueviolet);
    attackSlider->setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::blueviolet);
    attackSlider->addListener (this);

    attackSlider->setBounds (376, 136, 152, 24);

    attackLabel.reset (new juce::Label ("Attack Label",
                                        TRANS("Attack Label (time(s) before input and output have the same level after Noise Gate deactivates)")));
    addAndMakeVisible (attackLabel.get());
    attackLabel->setFont (juce::Font (15.70f, juce::Font::plain).withTypefaceStyle ("Regular"));
    attackLabel->setJustificationType (juce::Justification::centredLeft);
    attackLabel->setEditable (false, false, false);
    attackLabel->setColour (juce::TextEditor::textColourId, juce::Colours::black);
    attackLabel->setColour (juce::TextEditor::backgroundColourId, juce::Colour (0x00000000));

    attackLabel->setBounds (304, 88, 272, 40);

    alphaSlider.reset (new juce::Slider ("Alpha Slider"));
    addAndMakeVisible (alphaSlider.get());
    alphaSlider->setRange (-200, 0, 0);
    alphaSlider->setSliderStyle (juce::Slider::LinearHorizontal);
    alphaSlider->setTextBoxStyle (juce::Slider::TextBoxLeft, false, 80, 20);
    alphaSlider->setColour (juce::Slider::thumbColourId, juce::Colours::blueviolet);
    alphaSlider->setColour (juce::Slider::rotarySliderOutlineColourId, juce::Colours::blueviolet);
    alphaSlider->setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::blueviolet);
    alphaSlider->addListener (this);

    alphaSlider->setBounds (360, 264, 150, 24);

    alphaLabel.reset (new juce::Label ("Alpha Label",
                                       TRANS("Alpha Label (choose a value for the pole placement. !! BELOW )!!)")));
    addAndMakeVisible (alphaLabel.get());
    alphaLabel->setFont (juce::Font (15.00f, juce::Font::plain).withTypefaceStyle ("Regular"));
    alphaLabel->setJustificationType (juce::Justification::centredLeft);
    alphaLabel->setEditable (false, false, false);
    alphaLabel->setColour (juce::TextEditor::textColourId, juce::Colours::black);
    alphaLabel->setColour (juce::TextEditor::backgroundColourId, juce::Colour (0x00000000));

    alphaLabel->setBounds (352, 192, 248, 56);


    //[UserPreSize]
    //[/UserPreSize]

    setSize (600, 300);


    //[Constructor] You can add your own custom stuff here..
    getProcessor()->RequestUIUpdate();
    startTimer(200);

    //[/Constructor]
}

NoiseGateAudioProcessorEditor::~NoiseGateAudioProcessorEditor()
{
    //[Destructor_pre]. You can add your own custom destruction code here..
    //[/Destructor_pre]

    uthcntSlider = nullptr;
    uthcntLabel = nullptr;
    lthcntSlider = nullptr;
    lthcntLabel = nullptr;
    holdtimeSlider = nullptr;
    holdtimeLabel = nullptr;
    releaseSlider = nullptr;
    releaseLabel = nullptr;
    attackSlider = nullptr;
    attackLabel = nullptr;
    alphaSlider = nullptr;
    alphaLabel = nullptr;


    //[Destructor]. You can add your own custom destruction code here..
    //[/Destructor]
}

//==============================================================================
void NoiseGateAudioProcessorEditor::paint (juce::Graphics& g)
{
    //[UserPrePaint] Add your own custom painting code here..
    //[/UserPrePaint]

    g.fillAll (juce::Colour (0xff470a38));

    //[UserPaint] Add your own custom painting code here..
    //[/UserPaint]
}

void NoiseGateAudioProcessorEditor::resized()
{
    //[UserPreResize] Add your own custom resize code here..
    //[/UserPreResize]

    //[UserResized] Add your own custom resize handling here..
    //[/UserResized]
}

void NoiseGateAudioProcessorEditor::sliderValueChanged (juce::Slider* sliderThatWasMoved)
{
    //[UsersliderValueChanged_Pre]

    NoiseGateAudioProcessor* ourProcessor = getProcessor();

    //[/UsersliderValueChanged_Pre]

    if (sliderThatWasMoved == uthcntSlider.get())
    {
        //[UserSliderCode_uthcntSlider] -- add your slider handling code here..
        ourProcessor->setParameter(NoiseGateAudioProcessor::uthcnt, (float)uthcntSlider->getValue());
        //[/UserSliderCode_uthcntSlider]
    }
    else if (sliderThatWasMoved == lthcntSlider.get())
    {
        //[UserSliderCode_lthcntSlider] -- add your slider handling code here..
        ourProcessor->setParameter(NoiseGateAudioProcessor::lthcnt, (float)lthcntSlider->getValue());
        //[/UserSliderCode_lthcntSlider]
    }
    else if (sliderThatWasMoved == holdtimeSlider.get())
    {
        //[UserSliderCode_holdtimeSlider] -- add your slider handling code here..
        ourProcessor->setParameter(NoiseGateAudioProcessor::holdtime, (float)holdtimeSlider->getValue());
        //[/UserSliderCode_holdtimeSlider]
    }
    else if (sliderThatWasMoved == releaseSlider.get())
    {
        //[UserSliderCode_releaseSlider] -- add your slider handling code here..
        ourProcessor->setParameter(NoiseGateAudioProcessor::release, (float)releaseSlider->getValue());
        //[/UserSliderCode_releaseSlider]
    }
    else if (sliderThatWasMoved == attackSlider.get())
    {
        //[UserSliderCode_attackSlider] -- add your slider handling code here..
        ourProcessor->setParameter(NoiseGateAudioProcessor::attack, (float)attackSlider->getValue());
        //[/UserSliderCode_attackSlider]
    }
    else if (sliderThatWasMoved == alphaSlider.get())
    {
        //[UserSliderCode_alphaSlider] -- add your slider handling code here..
        ourProcessor->setParameter(NoiseGateAudioProcessor::alpha, (float)alphaSlider->getValue());
        //[/UserSliderCode_alphaSlider]
    }

    //[UsersliderValueChanged_Post]
    //[/UsersliderValueChanged_Post]
}



//[MiscUserCode] You can add your own definitions of your custom methods or any other code here...
void NoiseGateAudioProcessorEditor::timerCallback()
{
    NoiseGateAudioProcessor* ourProcessor = getProcessor();

    if (ourProcessor->NeedsUIUpdate())
    {
        uthcntSlider->setValue(ourProcessor->getParameter(NoiseGateAudioProcessor::uthcnt), juce::dontSendNotification);
        lthcntSlider->setValue(ourProcessor->getParameter(NoiseGateAudioProcessor::lthcnt), juce::dontSendNotification);
        holdtimeSlider->setValue(ourProcessor->getParameter(NoiseGateAudioProcessor::holdtime), juce::dontSendNotification);
        attackSlider->setValue(ourProcessor->getParameter(NoiseGateAudioProcessor::attack), juce::dontSendNotification);
        releaseSlider->setValue(ourProcessor->getParameter(NoiseGateAudioProcessor::release), juce::dontSendNotification);
        ourProcessor->ClearUIUpdateFlag();
        alphaSlider->setValue(ourProcessor->getParameter(NoiseGateAudioProcessor::alpha), juce::dontSendNotification);
        ourProcessor->ClearUIUpdateFlag();
    }

}

//[/MiscUserCode]


//==============================================================================
#if 0
/*  -- Projucer information section --

    This is where the Projucer stores the metadata that describe this GUI layout, so
    make changes in here at your peril!

BEGIN_JUCER_METADATA

<JUCER_COMPONENT documentType="Component" className="NoiseGateAudioProcessorEditor"
                 componentName="" parentClasses="public AudioProcessorEditor, public Timer"
                 constructorParams="NoiseGateAudioProcessor* ownerFilter" variableInitialisers="AudioProcessorEditor(ownerFilter)"
                 snapPixels="8" snapActive="1" snapShown="1" overlayOpacity="0.330"
                 fixedSize="1" initialWidth="600" initialHeight="300">
  <BACKGROUND backgroundColour="ff470a38"/>
  <SLIDER name="Uthcnt Slider" id="64a594c3fceb9eaa" memberName="uthcntSlider"
          virtualName="" explicitFocusOrder="0" pos="16 56 167 24" thumbcol="ff9a39e1"
          textboxoutline="ffb775f0" min="0.0" max="-140.0" int="1.0" style="LinearHorizontal"
          textBoxPos="TextBoxLeft" textBoxEditable="1" textBoxWidth="80"
          textBoxHeight="20" skewFactor="1.0" needsCallback="1"/>
  <LABEL name="Uthcnt Label" id="e5d51f1a86a88a1b" memberName="uthcntLabel"
         virtualName="" explicitFocusOrder="0" pos="16 -8 175 80" edTextCol="ff000000"
         edBkgCol="0" labelText="Uthcnt Label(deactivates the Noise Gate)"
         editableSingleClick="0" editableDoubleClick="0" focusDiscardsChanges="0"
         fontname="Default font" fontsize="15.1" kerning="0.0" bold="0"
         italic="0" justification="33"/>
  <SLIDER name="Lthcnt Slider" id="c9277a906b928503" memberName="lthcntSlider"
          virtualName="" explicitFocusOrder="0" pos="368 56 160 24" thumbcol="ff8a2be2"
          textboxoutline="ff8a2be2" min="-60.0" max="0.0" int="1.0" style="LinearHorizontal"
          textBoxPos="TextBoxLeft" textBoxEditable="1" textBoxWidth="80"
          textBoxHeight="20" skewFactor="1.0" needsCallback="1"/>
  <LABEL name="Lthcnt Label" id="747fcce95ea03b37" memberName="lthcntLabel"
         virtualName="" explicitFocusOrder="0" pos="368 -8 184 72" edTextCol="ff000000"
         edBkgCol="0" labelText="Lthcnt Label (activates the Noise Gate)"
         editableSingleClick="0" editableDoubleClick="0" focusDiscardsChanges="0"
         fontname="Default font" fontsize="15.6" kerning="0.0" bold="0"
         italic="0" justification="33"/>
  <SLIDER name="Holdtime Slider" id="37a02bfeef31c171" memberName="holdtimeSlider"
          virtualName="" explicitFocusOrder="0" pos="16 152 160 24" thumbcol="ff8a2be2"
          textboxoutline="ff8a2be2" min="0.0" max="4.0" int="0.0" style="LinearHorizontal"
          textBoxPos="TextBoxLeft" textBoxEditable="1" textBoxWidth="80"
          textBoxHeight="20" skewFactor="1.0" needsCallback="1"/>
  <LABEL name="Holdtime Label" id="8c648b4132aef1c7" memberName="holdtimeLabel"
         virtualName="" explicitFocusOrder="0" pos="8 80 256 72" edTextCol="ff000000"
         edBkgCol="0" labelText="Holdtime Label (time (s) the sound has the value of Lthcnt before the Noise Gate activates)"
         editableSingleClick="0" editableDoubleClick="0" focusDiscardsChanges="0"
         fontname="Default font" fontsize="15.0" kerning="0.0" bold="0"
         italic="0" justification="33"/>
  <SLIDER name="Release Slider" id="3af7cc1015e6c76c" memberName="releaseSlider"
          virtualName="" explicitFocusOrder="0" pos="24 256 152 24" thumbcol="ff8a2be2"
          textboxoutline="ff8a2be2" min="0.0" max="4.0" int="0.0" style="LinearHorizontal"
          textBoxPos="TextBoxLeft" textBoxEditable="1" textBoxWidth="80"
          textBoxHeight="20" skewFactor="1.0" needsCallback="1"/>
  <LABEL name="Release Label" id="607d62703a80a76c" memberName="releaseLabel"
         virtualName="" explicitFocusOrder="0" pos="16 200 231 40" edTextCol="ff000000"
         edBkgCol="0" labelText="Release Label (time(s) before the sound level reaches 0)"
         editableSingleClick="0" editableDoubleClick="0" focusDiscardsChanges="0"
         fontname="Default font" fontsize="15.0" kerning="0.0" bold="0"
         italic="0" justification="33"/>
  <SLIDER name="Attack Slider" id="c9ba33008fc1d66f" memberName="attackSlider"
          virtualName="" explicitFocusOrder="0" pos="376 136 152 24" thumbcol="ff8a2be2"
          textboxoutline="ff8a2be2" min="0.0" max="4.0" int="0.0" style="LinearHorizontal"
          textBoxPos="TextBoxLeft" textBoxEditable="1" textBoxWidth="80"
          textBoxHeight="20" skewFactor="1.0" needsCallback="1"/>
  <LABEL name="Attack Label" id="ecb7e8435b8a1b9b" memberName="attackLabel"
         virtualName="" explicitFocusOrder="0" pos="304 88 272 40" edTextCol="ff000000"
         edBkgCol="0" labelText="Attack Label (time(s) before input and output have the same level after Noise Gate deactivates)"
         editableSingleClick="0" editableDoubleClick="0" focusDiscardsChanges="0"
         fontname="Default font" fontsize="15.7" kerning="0.0" bold="0"
         italic="0" justification="33"/>
  <SLIDER name="Alpha Slider" id="13683b4eb6ec83ac" memberName="alphaSlider"
          virtualName="" explicitFocusOrder="0" pos="360 264 150 24" thumbcol="ff8a2be2"
          rotaryslideroutline="ff8a2be2" textboxoutline="ff8a2be2" min="-200.0"
          max="0.0" int="0.0" style="LinearHorizontal" textBoxPos="TextBoxLeft"
          textBoxEditable="1" textBoxWidth="80" textBoxHeight="20" skewFactor="1.0"
          needsCallback="1"/>
  <LABEL name="Alpha Label" id="964060d9cd1af9c8" memberName="alphaLabel"
         virtualName="" explicitFocusOrder="0" pos="352 192 248 56" edTextCol="ff000000"
         edBkgCol="0" labelText="Alpha Label (choose a value for the pole placement. !! BELOW )!!)"
         editableSingleClick="0" editableDoubleClick="0" focusDiscardsChanges="0"
         fontname="Default font" fontsize="15.0" kerning="0.0" bold="0"
         italic="0" justification="33"/>
</JUCER_COMPONENT>

END_JUCER_METADATA
*/
#endif


//[EndFile] You can add extra defines here...
//[/EndFile]

