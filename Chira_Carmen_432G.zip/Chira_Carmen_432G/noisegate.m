close all
clear
clc

[x, Fs] = audioread("drum1.wav");
sound(x(1:2*Fs), Fs)
pause(2)
t = 0:1/Fs:length(x)/Fs-1/Fs;
figure(1)
plot(t,x)

X= fft(x);
f = 0:Fs/length(X):Fs/2-Fs/length(X);
figure(2)
plot(f,20*log10(abs(X(1:length(X)/2))))

y = noisegt(x,0.05,-70,0,0.2,0.05,0.7,Fs);

figure(3)
plot(t,y)

X= fft(y);
f = 0:Fs/length(X):Fs/2-Fs/length(X);
figure(4)
plot(f,20*log10(abs(X(1:length(X)/2))))
sound(y(1:2*Fs), Fs)